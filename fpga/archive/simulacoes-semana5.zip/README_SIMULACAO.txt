Simulações da Semana 5 - Aventura Financeira Evolution (BA6, Turma 6)

Conteúdo
  fpga/rtl/                      fontes RTL finais (3 vidas, estudo sem custo,
                                 INVESTIR/RESGATAR de 10.000 por vez, telemetria AEF2)
  fpga/testbench/                testbenches gerais
  fpga/testbench/semana3/        testbenches da semana 3
  fpga/testbench/semana4/        testbench da interface da caixa e scripts da semana 4
  fpga/testbench/semana5/        script da regressão final (run_semana5.do)

Cenário 11 (numeração do relatório): regressão final com 3 vidas
  processador_acao_tb, rfid_uart_rx_tb, rfid_uart_rx_semana3_tb,
  seletor_item_telemetria_tb, telemetria_uart_tb (quadro AEF2, com vidas),
  unidade_controle_moore_tb, unidade_controle_semana3_tb (caminho PERDE_VIDA),
  circuito_jogo_financeiro_tb1 e circuito_caixa_semana4_tb (78 verificações;
  no caso 8 a compra sem saldo tira 1 vida em vez de ir direto à falência)

Como executar (ModelSim/Questa), na pasta onde o zip foi extraído:
  vsim -c -do fpga/testbench/semana5/run_semana5.do      (modo texto, todos)
  vsim -do fpga/testbench/semana4/wave_semana4.do        (formas de onda da caixa)

Com Icarus Verilog (exemplo para o testbench da caixa):
  iverilog -g2012 -s circuito_caixa_semana4_tb -o s5 fpga/rtl/*.v fpga/testbench/semana4/circuito_caixa_semana4_tb.v
  vvp s5 +vcd

Resultado esperado: uma linha PASS (ou mensagem de sucesso) por testbench e nenhum
erro. O testbench da caixa imprime um AVISO: o evento 12 (fim de jogo) da
telemetria é enviado quando começa a última jogada, antes de a UC chegar a
FIM_JOGO. A não conformidade está descrita no relatório (Tabela 22).
