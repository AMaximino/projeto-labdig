Simulações da Semana 4 - Aventura Financeira Evolution (BA6, Turma 6)

Conteúdo
  fpga/rtl/                      fontes RTL do projeto (sem alterações desde a semana 3)
  fpga/testbench/                testbenches gerais (regressão)
  fpga/testbench/semana3/        testbenches da semana 3 (regressão)
  fpga/testbench/semana4/        testbench e scripts da semana 4

Cenários (numeração do relatório)
  8   regressão: todos os testbenches anteriores
        processador_acao_tb, rfid_uart_rx_tb, rfid_uart_rx_semana3_tb,
        seletor_item_telemetria_tb, telemetria_uart_tb, unidade_controle_moore_tb,
        unidade_controle_semana3_tb, circuito_jogo_financeiro_tb1
  10  circuito_caixa_semana4_tb: interface física da caixa no topo do circuito
        botões e seletor ativos em 0, cartão RFID pela UART (RNN\n), LEDs dos
        itens, painel de consulta, falência, fim de jogo e LEDs ÚLTIMA
  (O cenário 9, verificação do modelo da caixa, roda em modelagem/caixa.py.)

Como executar (ModelSim/Questa), na pasta onde o zip foi extraído:
  vsim -c -do fpga/testbench/semana4/run_semana4.do      (modo texto, todos)
  vsim -do fpga/testbench/semana4/wave_semana4.do        (formas de onda do cenário 10)

Com Icarus Verilog:
  iverilog -g2012 -s circuito_caixa_semana4_tb -o s4 fpga/rtl/*.v fpga/testbench/semana4/circuito_caixa_semana4_tb.v
  vvp s4 +vcd        (+vcd grava semana4.vcd para o GTKWave)

Resultado esperado: uma linha PASS (ou mensagem de sucesso) por testbench e nenhum
erro. O cenário 10 imprime um AVISO: o evento 12 (fim de jogo) da telemetria é
enviado quando começa a última jogada, antes de a UC chegar a FIM_JOGO; o LED
FIM DO JOGO (terminou) está correto. A não conformidade está descrita no relatório.

O testbench do cenário 10 reduz o divisor de clock do topo por defparam
(CLOCK_DIV = 4) para a partida completa simular em poucos segundos; a lógica do
jogo é a mesma e a UART continua a 115200 baud.
