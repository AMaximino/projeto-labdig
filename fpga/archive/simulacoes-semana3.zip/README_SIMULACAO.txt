Simulações da Semana 3 - Aventura Financeira Evolution (BA6, Turma 6)

Conteúdo
  fpga/rtl/                      fontes RTL do projeto (todas, usadas pelos testbenches)
  fpga/testbench/semana3/        testbenches e script da semana 3
  fpga/testbench/processador_acao_tb.v
  fpga/testbench/seletor_item_telemetria_tb.v

Cenários (numeração do relatório)
  1 a 4  unidade_controle_semana3_tb   reset/início, ações e display, jogadas e rodadas, fim de jogo e falência
  5      rfid_uart_rx_semana3_tb       recepção do comando RFID RNN\n (faixa, retenção, acknowledge, sobrescrita)
  6      processador_acao_tb           compra sem saldo aprovada com saldo negativo; item repetido recusado
  7      seletor_item_telemetria_tb    evento 14 do seletor (estabilidade, bounce, posição inválida, ESPERA_ACAO)

Como executar (ModelSim/Questa), na pasta onde o zip foi extraído:
  vsim -c -do fpga/testbench/semana3/run_semana3.do

Resultado esperado: uma linha PASS (ou "Compra sem saldo aceita...") por testbench
e nenhum erro. Verificado no ModelSim ASE 18.1 e no Icarus Verilog.
