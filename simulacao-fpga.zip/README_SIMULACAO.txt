SIMULACAO FPGA - AVENTURA FINANCEIRA

Conteudo: fontes RTL, tres testbenches automatizados, testbench completo de
integracao, script ModelSim/QuestaSim e configuracao de ondas.

ModelSim/QuestaSim (a partir desta pasta):
  vsim -do fpga/testbench/run_all.do

Testbench completo interativo (a partir desta pasta):
  vlog -sv circuito/*.v fpga/testbench/circuito_jogo_financeiro_tb1.v
  vsim work.circuito_jogo_financeiro_tb1
  do sim/wave.do
  run -all

Icarus Verilog - exemplo para a telemetria UART:
  iverilog -g2012 -s telemetria_uart_tb -o /tmp/aef_uart.vvp circuito/*.v fpga/testbench/telemetria_uart_tb.v
  vvp /tmp/aef_uart.vvp

Execute os comandos na raiz descompactada. Requer ModelSim/QuestaSim ou,
para a alternativa de terminal, Icarus Verilog instalado.
