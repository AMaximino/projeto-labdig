module fluxo_dados (
    input clock,
    input estudar,
    input trabalhar,
    input investir,
    input resgatar,
    input comprar,
    input vender,
    input [5:0] config_display,
    input [9:0] seletor_item,

    input rstED,
    input init,
    input processaE,
    input rende,
    input despesa,
    input zeraCJ,
    input contaCJ,
    input zeraCR,
    input contaCR,
    input zeraD,
    input registraD,
    input zeraA,
    input registraA,
    input zeraV,
    input registraV,
    input zeraM,
    input registraM,

    output fim_jogo,
    output fim_perdeu,
    output fim_rodada,
    output acao_pulso,
    output eh_jogada,
    output display_pulso,
    output [3:0] contagem, //
    output [3:0] rodada, //

    output ultima_rodada,
    output [23:0] dinheiro,
    output [9:0] itens_out,
    output reg telemetry_send,
    output reg [7:0] telemetry_event,
    output reg [1:0] telemetry_status,
    output reg [3:0] telemetry_item,
    output signed [20:0] telemetry_balance,
    output signed [20:0] telemetry_salary,
    output signed [20:0] telemetry_investment,
    output signed [20:0] telemetry_fixed_expenses,
    output signed [20:0] telemetry_unique_expenses
);

    //em complemento de 2 -> bit 21 = 1 indica negativo
    wire [20:0] saldo;
    wire [20:0] saldo_next;
    wire [20:0] salario;
    wire [20:0] salario_next;
    wire [20:0] valorInvestido;
    wire [20:0] valorInvestido_next;
    wire [20:0] rendimento;
    wire [20:0] rendimento_next;
    wire [20:0] gastosFixos;
    wire [20:0] gastosFixos_next;
    wire [20:0] gastosUnicos;
    wire [20:0] gastosUnicos_next;
    wire [9:0] itens;
    wire [9:0] itens_next;

    wire [5:0] acoes_out;

    assign itens_out = itens;
    assign telemetry_balance = saldo;
    assign telemetry_salary = salario;
    assign telemetry_investment = valorInvestido;
    assign telemetry_fixed_expenses = gastosFixos;
    assign telemetry_unique_expenses = gastosUnicos;

    reg terminal_sent;

/////////////display/////////////////////////////////
    wire sel_display;
    wire [5:0] config_display_out;
    wire [2:0] addr_read;

    edge_detector sel_display_ED (
        .clock ( clock ),
        .reset ( rstED ),
        .sinal ( sel_display ),
        .pulso ( display_pulso )
    );
    assign sel_display = |config_display;

    // registrador da opcao de selecao do display
    registrador_n #(.N(6)) regDisplay (
        .clock  ( clock ),
        .clear  ( zeraD ),
        .enable ( registraD ),
        .D      ( config_display ),
        .Q      ( config_display_out )
    );

    /*// transformador de formato de config_display (botoes) p/ endereco de leitura
    encoder #(.N(6)) addr_display (
        .entrada ( config_display_out ),
        .saida ( addr_read )
    );*/


    sel_dinheiro selDisplayDinheiro (
        .saldo          ( saldo ),
        .salario        ( salario ),
        .valorInvestido ( valorInvestido ),
        .rendimento     ( rendimento ),
        .gastosFixos    ( gastosFixos ),
        .gastosUnicos   ( gastosUnicos ),
        .config_display ( config_display_out ),
        .dinheiro       ( dinheiro )
    );

///////////info/////////////////////////////////////////////////////////////////////////
    
    registrador_n #(.N(21)) reg_saldo (
        .clock  ( clock ),
        .clear  ( zeraV ),
        .enable ( registraV ),
        .D      ( saldo_next ),
        .Q      ( saldo )
    );
    registrador_n #(.N(21)) reg_salario (
        .clock  ( clock ),
        .clear  ( zeraV ),
        .enable ( registraV ),
        .D      ( salario_next ),
        .Q      ( salario )
    );
    registrador_n #(.N(21)) reg_valorInvestido (
        .clock  ( clock ),
        .clear  ( zeraV ),
        .enable ( registraV ),
        .D      ( valorInvestido_next ),
        .Q      ( valorInvestido )
    );
    /*registrador_n #(.N(21)) reg_rendimento (
        .clock  ( clock ),
        .clear  ( zeraV ),
        .enable ( registraV ),
        .D      ( rendimento_next ),
        .Q      ( rendimento )
    );*/
    assign rendimento = valorInvestido >> 2; //25% ao ano (rodada)
    registrador_n #(.N(21)) reg_gastosFixos (
        .clock  ( clock ),
        .clear  ( zeraV ),
        .enable ( registraV ),
        .D      ( gastosFixos_next ),
        .Q      ( gastosFixos )
    );
    registrador_n #(.N(21)) reg_gastosUnicos (
        .clock  ( clock ),
        .clear  ( zeraV ),
        .enable ( registraV ),
        .D      ( gastosUnicos_next ),
        .Q      ( gastosUnicos )
    );

    registrador_n #(.N(10)) reg_itens (
        .clock  ( clock ),
        .clear  ( zeraV ),
        .enable ( registraV ),
        .D      ( itens_next ),
        .Q      ( itens )
    );

///////////////////////////////////////////////////////////////////////////
////////////////processamento//////////////////////////////////////////////

    wire [20:0] saldo_proc;
    wire [20:0] salario_proc;
    wire [20:0] valorInvestido_proc;
    wire [20:0] gastosFixos_proc;
    wire [20:0] gastosUnicos_proc;
    wire [9:0]  itens_proc;
    wire acao_aceita;
    processador_acao pa (
        .saldo_in            ( saldo ),
        .salario_in          ( salario ),
        .valorInvestido_in   ( valorInvestido ),
        .gastosFixos_in      ( gastosFixos ),
        .gastosUnicos_in     ( gastosUnicos ),
        .acao                ( acoes_out ),
        .processaE           ( processaE ),
        .seletor_item        ( seletor_item ),
        .itens_in            ( itens ),
        .saldo_out           ( saldo_proc ),
        .salario_out         ( salario_proc ),
        .valorInvestido_out  ( valorInvestido_proc ),
        .gastosFixos_out     ( gastosFixos_proc ),
        .gastosUnicos_out    ( gastosUnicos_proc ),
        .itens_out           ( itens_proc ),
        .acao_aceita         ( acao_aceita )
    );

    function [3:0] item_id;
        input [9:0] seletor;
        begin
            case (seletor)
                10'b0000000001: item_id = 4'd1;
                10'b0000000010: item_id = 4'd2;
                10'b0000000100: item_id = 4'd3;
                10'b0000001000: item_id = 4'd4;
                10'b0000010000: item_id = 4'd5;
                10'b0000100000: item_id = 4'd6;
                10'b0001000000: item_id = 4'd7;
                10'b0010000000: item_id = 4'd8;
                10'b0100000000: item_id = 4'd9;
                10'b1000000000: item_id = 4'd10;
                default: item_id = 4'd0;
            endcase
        end
    endfunction

    always @(posedge clock) begin
        if (rstED) begin
            telemetry_send <= 1'b0;
            telemetry_event <= 8'd0;
            telemetry_status <= 2'd0;
            telemetry_item <= 4'd0;
            terminal_sent <= 1'b0;
        end else if (init) begin
            telemetry_send <= 1'b1;
            telemetry_event <= 8'd1;
            telemetry_status <= 2'd0;
            telemetry_item <= 4'd0;
            terminal_sent <= 1'b0;
        end else begin
            telemetry_send <= 1'b0;
            if (processaE && (acoes_out != 6'b010000) && (acoes_out != 6'b100000)) begin
                telemetry_send <= 1'b1;
                telemetry_item <= item_id(seletor_item);
                telemetry_status <= acao_aceita ? 2'd1 : 2'd2;
                case (acoes_out)
                    6'b010000: telemetry_event <= 8'd2;
                    6'b100000: telemetry_event <= 8'd3;
                    6'b001000: telemetry_event <= 8'd4;
                    6'b000100: telemetry_event <= 8'd5;
                    6'b000010: telemetry_event <= acao_aceita ? 8'd6 : 8'd7;
                    6'b000001: telemetry_event <= acao_aceita ? 8'd8 : 8'd9;
                    default:   telemetry_event <= 8'd0;
                endcase
            end else if (despesa) begin
                telemetry_send <= 1'b1;
                telemetry_event <= acoes_out == 6'b010000 ? 8'd2 : 8'd3;
                telemetry_status <= 2'd1;
                telemetry_item <= 4'd0;
            end else if (rende) begin
                telemetry_send <= 1'b1;
                telemetry_event <= 8'd11;
                telemetry_status <= 2'd0;
                telemetry_item <= 4'd0;
            end else if (!terminal_sent && fim_jogo) begin
                telemetry_send <= 1'b1;
                telemetry_event <= 8'd12;
                telemetry_status <= 2'd0;
                telemetry_item <= 4'd0;
                terminal_sent <= 1'b1;
            end else if (!terminal_sent && fim_perdeu) begin
                telemetry_send <= 1'b1;
                telemetry_event <= 8'd13;
                telemetry_status <= 2'd0;
                telemetry_item <= 4'd0;
                terminal_sent <= 1'b1;
            end
        end
    end

    wire [20:0] saldo_evento;
    wire [20:0] salario_evento;
    wire [20:0] valorInvestido_evento;
    wire [20:0] gastosFixos_evento;
    wire [20:0] gastosUnicos_evento;
    processador_evento pe (
        .saldo_in            ( saldo ),
        .salario_in          ( salario ),
        .valorInvestido_in   ( valorInvestido ),
        .rendimento_in       ( rendimento ),
        .gastosFixos_in      ( gastosFixos ),
        .gastosUnicos_in     ( gastosUnicos ),
        .rende               ( rende ),
        .despesa             ( despesa ),
        .saldo_out           ( saldo_evento ),
        .salario_out         ( salario_evento ),
        .valorInvestido_out  ( valorInvestido_evento ),
        .gastosFixos_out     ( gastosFixos_evento ),
        .gastosUnicos_out    ( gastosUnicos_evento )
    );

    wire [20:0] saldo_init;
    wire [20:0] salario_init;
    wire [20:0] valorInvestido_init;
    wire [20:0] gastosFixos_init;
    wire [20:0] gastosUnicos_init;
    wire [9:0]  itens_init;
    inicializador i (
        .saldo          ( saldo_init ),
        .salario        ( salario_init ),
        .valorInvestido ( valorInvestido_init ),
        .gastosFixos    ( gastosFixos_init ),
        .gastosUnicos   ( gastosUnicos_init ),
        .itens          ( itens_init )
    );

    sel_valor MUX (
        .saldo_init            ( saldo_init ),
        .salario_init          ( salario_init ),
        .valorInvestido_init   ( valorInvestido_init ),
        .gastosFixos_init      ( gastosFixos_init ),
        .gastosUnicos_init     ( gastosUnicos_init ),
        .itens_init            ( itens_init ),
        .saldo_proc            ( saldo_proc ),
        .salario_proc          ( salario_proc ),
        .valorInvestido_proc   ( valorInvestido_proc ),
        .gastosFixos_proc      ( gastosFixos_proc ),
        .gastosUnicos_proc     ( gastosUnicos_proc ),
        .itens_proc            ( itens_proc ),
        .saldo_evento          ( saldo_evento ),
        .salario_evento        ( salario_evento ),
        .valorInvestido_evento ( valorInvestido_evento ),
        .gastosFixos_evento    ( gastosFixos_evento ),
        .gastosUnicos_evento   ( gastosUnicos_evento ),
        .init                  ( init ),
        .processaE             ( processaE ),
        .saldo_out             ( saldo_next ),
        .salario_out           ( salario_next ),
        .valorInvestido_out    ( valorInvestido_next ),
        .gastosFixos_out       ( gastosFixos_next ),
        .gastosUnicos_out      ( gastosUnicos_next ),
        .itens_out             ( itens_next )
    );

//////////////////////////////////////////////////////////////////
////////////////acao//////////////////////////////////////////////

    wire [5:0] acoes;
    wire tem_acao;

    edge_detector acao_ED (
        .clock ( clock ),
        .reset ( rstED ),
        .sinal ( tem_acao ),
        .pulso ( acao_pulso )
    );
    assign acoes = {estudar, trabalhar, investir, resgatar, comprar, vender};
    assign tem_acao = |acoes;
    

    // registrador da acao realizada
    registrador_n #(.N(6)) regAcao (
        .clock  ( clock ),
        .clear  ( zeraA ),
        .enable ( registraA ),
        .D      ( acoes ),
        .Q      ( acoes_out )
    );
    

///////////////////////////////////////////////////////////////////////////////
//////////////jogada/////////////////////////////////////////////////////////
    wire [1:0] jogada;
    assign jogada = {acoes_out[5], acoes_out[4]};
    assign eh_jogada = |jogada;
    


    // contador_modulo_n contadorJogada
    contador_modulo_n #(.N(4)) contadorJogada (
      .clock  ( clock ),
      .clr    ( ~zeraCJ ),
      .ld     ( 1'b1 ),
      .ent    ( 1'b1 ),
      .enp    ( contaCJ ),
      .modulo ( 4'b0010 ),  //(modulo +1) jogadas, 3 jogadas -> 3 quadris por rodada (ano)
      .D      ( 4'b0000 ),     
      .Q      ( contagem ),
      .rco    ( fim_rodada )
    );
    // 1 jogada -> 1 quadrimestre


    // contador_modulo_n contadorRodada
    contador_modulo_n #(.N(4)) contadorRodada (
      .clock  ( clock ),
      .clr    ( ~zeraCR ),
      .ld     ( 1'b1 ),
      .ent    ( 1'b1 ),
      .enp    ( contaCR ),
      .modulo ( 4'b1110),  //(modulo + 1) rodadas, 15 rodadas -> 15 trimestres no jogo
      .D      ( 4'b0000 ),     
      .Q      ( rodada ),
      .rco    ( ultima_rodada )
    );

    assign fim_jogo = fim_rodada && ultima_rodada;
    assign fim_perdeu = saldo[20];

endmodule